### Bottom Left Diagonal
![image](image.png)

### Upper Left Diagonal
![image](image_2.png)