![image](image.png)
### Function Overriding
![image](image_2.png)

![image](image_3.png)

![image](image_4.png)
![image](image_5.png)
![image](image_6.png)