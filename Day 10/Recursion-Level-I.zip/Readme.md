# Ek Case Solve Kardo Baki Sab Recursion Sambhal Leta Hai
## Just Believe On It Dont Doubt On Recursion
### Recursive Call Stack
![image](image.png)
### Recursive Tree
![image](image_2.png)
### Reverse Printing
![image](image_3.png)
### Factorial
![image](image_4.png)
### Normal Printing
![image](image_5.png)
### Fibonacci 
![image](image_6.png)