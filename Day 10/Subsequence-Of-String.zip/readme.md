### Include Exclude Pattern
### Pick Not Pick Pattern
### In DP & In Recursion
### From ith Position -> Two Option Are There - Include Or Exclude
![image](image.png)
![image](image_2.png)
![image](image_3.png)