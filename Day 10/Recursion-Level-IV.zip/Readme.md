### Target Summ = Coin Chain Problem
### Pyq Of Adobe 
![image](image.png)

![image](image_2.png)

![image](image_4.png)

![image](image_5.png)